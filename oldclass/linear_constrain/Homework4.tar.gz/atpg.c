#include "atpgInt.h"
#include "bdd.h"

void Boolean_diff(int PIcnt, array_t *mddArray_PI, mdd_t *mddArray_PO, char **idx_PI)  // calculate primitive cover through boolean differential function
{
  bdd_t *node, *node_b, *cofactor, *cofactor_b, *idx_PO, *xor, *intersects, *intersects_b;
  int i = 0;
  for(i = 0; i < PIcnt; i ++)  // go through all PIs
    {
      printf("PI: %s    Fault: %s s-a-0\n", idx_PI[i], idx_PI[i]);
      node = (bdd_t *)array_fetch(mdd_t *, mddArray_PI, i);  // pick top (or front) mdd array
      idx_PO = (bdd_t *)mddArray_PO;  // transport into PO mdd array
      node_b = bdd_not(node);
      cofactor = bdd_cofactor(idx_PO, node);
      cofactor_b = bdd_cofactor(idx_PO, node_b);
      xor = bdd_xor(cofactor, cofactor_b);  // calculation for boolean difference
      intersects = bdd_intersects(xor, node);  // intersect to get primitive cover test vector
      bdd_print_cover(intersects);
      printf("PI: %s    Fault: %s s-a-1\n", idx_PI[i], idx_PI[i]);
      intersects_b = bdd_intersects(xor, node_b);  // for s-a-1 faults
      bdd_print_cover(intersects_b);
    }
}


/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/

void Atpg_Run(
	      Ntk_Network_t * network
	      )
{
  Ntk_Node_t *node;
  vertex_t *nodeVertex;
  mdd_manager *mddManager;
  Mvf_Function_t *func;
  mdd_t *mddTemp;
  graph_t *partition;

  /* Example of array_t initialization */
  array_t *mddArray = array_alloc (mdd_t *, 0);

  /* Example bdd nodes */
  bdd_t *g;
  
  lsGen          gen;

  int PIcnt = 0;  // Initialize count of PIs and POs from netlist
  array_t *mddArray_PI = array_alloc (mdd_t *, 0); // Create linking table working as stack(or queue?) for storing array from each PI
  char **idx_PI;  // char ** to store PIs' names
  int m = 99;
  idx_PI = (char **)malloc(sizeof(char *) *m);  // allocate idx memory
  
  mddManager = Ntk_NetworkReadMddManager (network);
  partition = (graph_t *) Ntk_NetworkReadApplInfo (network, PART_NETWORK_APPL_KEY);

  /*********************COMMENT*****************************/
  /* Look "ntk" package for more information about reading */
  /* nodes from network*************************************/
  /*********************************************************/
  
  Ntk_NetworkForEachPrimaryInput(network, gen, node){
    // (void) fprintf (vis_stdout, "Primary input: %s \t MddId: %d \n",
    //Ntk_NodeReadName(node), Ntk_NodeReadMddId(node));
     nodeVertex = Part_PartitionFindVertexByName(partition, Ntk_NodeReadName(node) );
     func = Part_VertexReadFunction(nodeVertex);
     mddTemp = Mvf_FunctionObtainComponent(func, 1);
     array_insert(mdd_t *, mddArray_PI, PIcnt, mddTemp);  //store generated mdd array of each PI
     PIcnt ++; 
     idx_PI[PIcnt-1] = Ntk_NodeReadName(node);  //store PIs' names
     //bdd_print((bdd_t *)mddTemp);
  }

  Ntk_NetworkForEachPrimaryOutput(network, gen, node){
    //(void) fprintf (vis_stdout, "Primary input: %s \t MddId: %d \n",
    //Ntk_NodeReadName(node), Ntk_NodeReadMddId(node));
     nodeVertex = Part_PartitionFindVertexByName(partition, Ntk_NodeReadName(node) );
     func = Part_VertexReadFunction(nodeVertex);
     mddTemp = Mvf_FunctionObtainComponent(func, 1);
     printf("For PO: %s    consider test vectors <PI1~PIn> w.r.t each PI below:\n", Ntk_NodeReadName(node));
     Boolean_diff(PIcnt, mddArray_PI, mddTemp, idx_PI);  // calculate PCover for this PO w.r.t each PI
     //bdd_print((bdd_t *)mddTemp);
  }
}
